<?php

    return array(
        'blog' => array(
            'Blog' => 'Günce',
            'Blog plugin for Monstra' => 'Monstra için günce eklentisi',
            'begin' => 'Baş',
            'end' => 'Son',
            'prev' => 'Önceki',
            'next' => 'Sonraki',
        ) 
    );
