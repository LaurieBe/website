<?php

    return array(
        'blog' => array(
            'Blog' => 'Blog',
            'Blog plugin for Monstra' => 'Wtyczka Blog dla systemu Monstra',
            'begin' => 'początek',
            'end' => 'koniec',
            'prev' => 'poprzedni',
            'next' => 'następny',
        ) 
    );