<?php

    return array(
        'blog' => array(
            'Blog' => 'Blog',
            'Blog plugin for Monstra' => 'Blog plugin for Monstra',
            'begin' => 'begin',
            'end' => 'end',
            'prev' => 'prev',
            'next' => 'next',
        ) 
    );