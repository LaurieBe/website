<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha Plugin voor Monstra',
            'Captcha code is wrong' => 'Captcha Code is helaas foutief',
        )
    );
