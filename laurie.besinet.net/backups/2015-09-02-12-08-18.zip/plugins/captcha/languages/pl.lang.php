<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Wtyczka Captcha dla systemu Monstra',
            'Captcha code is wrong' => 'Niewłaściwy kod Captcha',
        )
    );
