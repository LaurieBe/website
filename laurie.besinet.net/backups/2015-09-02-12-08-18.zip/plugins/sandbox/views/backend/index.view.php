Sandbox backend view
