<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Plugin Sandbox untuk Monstra',
            'Sandbox template' => 'Template Sandbox',
            'Save' => 'Simpan',
        )
    );
