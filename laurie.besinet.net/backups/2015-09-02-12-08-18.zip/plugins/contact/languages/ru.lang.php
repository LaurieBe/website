<?php

    return array(
        'contact' => array(
            'Contact' => 'Контакт',
            'Contact plugin for Monstra' => 'Плагин контакт для Монстра!',
            'Name' => 'Имя',
            'Email' => 'Емейл',
            'Message' => 'Сообщение',
            'Send' => 'Отправить',
            'Empty required fields!' => 'Пустые поля обязательные для заполнения!',
            'Email address is not valid!' => 'Адрес электронной почты не действителен!',
            'A letter has been sent!' => 'Письмо было отправлено!',
            'A Letter was not sent!' => 'Письмо не было отправлено!',
            'Wrong captcha!' => 'Неправильная капча!',
        ),
    );