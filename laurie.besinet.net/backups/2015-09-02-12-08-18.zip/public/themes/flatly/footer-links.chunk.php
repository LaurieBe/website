<br>
<table style="width:100%"><tr>
	<td style="width:33%"> 
		Contact : <a target="_blank" href="http://twitter.com/lauriebesinet" class="twitter" title="Twitter"><img src="http://besinet.net/public/uploads/twitter logo.jpg"></a>
		<a target="_blank" href="https://www.linkedin.com/in/lauriebesinet/fr" class="LinkedIn" title="LinkedIn"><img src="http://besinet.net/public/uploads/linkedin logo.jpg"></a>
		<a target="_blank" href="http://www.viadeo.com/fr/profile/laurie.besinet" class="Viadeo" title="Viadeo"><img src="http://besinet.net/public/uploads/Viadeo logo.jpg"></a>
		<a href="mailto:laurie@besinet.net" class="Mail" title="laurie@besinet.net"><img src="http://besinet.net/public/uploads/mail logo.jpg"></a>
 	</td>
	<td style="width:33%">
		<p style="text-align:center"><a href="http://besinet.net/">Accueil</a>  |  <a href="http://besinet.net/cv">CV</a></p>
	</td>
	<td style="width:33%">
		<p style="text-align:right">Cree par Laurie Besinet</p>
	</td>
</tr></table>




