<?php

    return array(
        'captcha' => array(
            'Captcha' => 'کدامنيتي',
            'Captcha plugin for Monstra' => 'کدامنيتي براي مونسترا',
            'Captcha code is wrong' => 'کدامنيتي اشتباه است',
        ) 
    );