<?php defined('MONSTRA_ACCESS') or die('No direct script access.');

// Delete Options
Option::delete('sandbox');
Option::delete('sandbox_template');
