Sandbox frontend view
