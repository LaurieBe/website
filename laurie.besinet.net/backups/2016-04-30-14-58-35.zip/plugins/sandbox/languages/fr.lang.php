<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Plugin Sandbox pour Monstra',
            'Sandbox template' => 'Modèle Sandbox',
            'Save' => 'Enregistrer',
        ) 
    );