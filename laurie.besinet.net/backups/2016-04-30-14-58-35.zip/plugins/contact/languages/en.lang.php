<?php

    return array(
        'contact' => array(
            'Contact' => 'Contact',
            'Contact plugin for Monstra' => 'Contact plugin for Monstra',
            'Name' => 'Name',
            'Email' => 'Email',
            'Message' => 'Message',
            'Send' => 'Send',
            'Empty required fields!' => 'Empty required fields!',
            'Email address is not valid!' => 'Email address is not valid!',
            'A letter has been sent!' => 'A letter has been sent!',
            'A Letter was not sent!' => 'A Letter was not sent!',
            'Wrong captcha!' => 'Wrong captcha!',
        ),
    );