<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html class="no-js lt-ie9 lt-ie8" lang="en"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html class="no-js lt-ie9" lang="en"><![endif]-->
<!--[if (IE 9)]><html class="no-js ie9" lang="en"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en-US"> <!--<![endif]-->



<head>

  <!-- Meta Tags -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

  <title id="i18n_title"></title>

  <meta name="description" content="Insert Your Site Description" />

  <!-- Mobile Specifics -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="HandheldFriendly" content="true"/>
  <meta name="MobileOptimized" content="320"/>

  <!-- Mobile Internet Explorer ClearType Technology -->
  <!--[if IEMobile]>  <meta http-equiv="cleartype" content="on">  <![endif]-->

  <!-- Bootstrap -->
  <link href="_include/css/bootstrap.min.css" rel="stylesheet">

  <!-- Main Style -->
  <link href="_include/css/main.css" rel="stylesheet">

  <!-- Supersized -->
  <link href="_include/css/supersized.css" rel="stylesheet">
  <link href="_include/css/supersized.shutter.css" rel="stylesheet">

  <!-- FancyBox -->
  <link href="_include/css/fancybox/jquery.fancybox.css" rel="stylesheet">

  <!-- Font Icons -->
  <link href="_include/css/fonts.css" rel="stylesheet">

  <!-- Shortcodes -->
  <link href="_include/css/shortcodes.css" rel="stylesheet">

  <!-- Responsive -->
  <link href="_include/css/bootstrap-responsive.min.css" rel="stylesheet">
  <link href="_include/css/responsive.css" rel="stylesheet">

  <!-- Supersized -->
  <link href="_include/css/supersized.css" rel="stylesheet">
  <link href="_include/css/supersized.shutter.css" rel="stylesheet">

  <!-- Google Font -->
  <link href='_include/css/css?family=Titillium+Web.css' rel='stylesheet' type='text/css'>

  <!-- Fav Icon -->
  <link rel="shortcut icon" href="#">

  <link rel="apple-touch-icon" href="#">
  <link rel="apple-touch-icon" sizes="114x114" href="#">
  <link rel="apple-touch-icon" sizes="72x72" href="#">
  <link rel="apple-touch-icon" sizes="144x144" href="#">

  <!-- Modernizr -->
  <script src="_include/js/modernizr.js"></script>

  <!-- Analytics -->
  <script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-66628748-4', 'auto');
    ga('send', 'pageview');
  </script>
  <!-- End Analytics -->
</head>

<body>

  <!-- This section is for Splash Screen -->
  <div class="ole">
    <section id="jSplash">
    	<div id="circle"></div>
    </section>
  </div>
  <!-- End of Splash Screen -->

  <!-- Header -->
  <?php include("header.php"); ?>

  <!-- Presentation Section -->
  <div id="nz" class="page">
  	<div class="container">
      	<!-- Title Page -->
        <div class="row">
            <div class="span12">
                <div class="title-page">
                    <h2 class="title">Coming soon ...</h2>
                </diV>
                    <br>
                <div>
                    <h2 class="title" style="text-transform: uppercase; text-align: center;">Le grand départ</h2>

                    Ce projet de voyage a commencé à germer de longs mois avant que je me retrouve dans un avion pour l'autre côté de la planète. Cet article décrit les questions que j'ai pu me poser et comment s'est organisé mon départ.
                    <br><br>
                    <h2 class="title" style="text-align: center;">Pourquoi voyager ?</h2>
                    <h3 class="title">Découvrir toujours plus</h3>
                    Quelques année auparavant, je suis partie vivre plusieurs mois aux États-Unis puis au Brésil. J'en suis revenue riche de <b>fantastiques découvertes</b> et de <b>rencontres inoubliables</b>.
                    <br><br>
                    <h3 class="title">M'enrichir au contact des Autres</h3>
                    Lors de ces voyages, j'ai pu voir les différences - linguistiques, cliturelles ou de niveau de vie - mais surtout les similarités - de tempérament, d'idées, de goûts - avec les personnes que j'ai rencontré. Voyager est à mes yeux un des meilleurs moyens pour développer l'<b>ouverture d'esprit</b>, le sens de l'<b>observation</b> et l'<b>empathie</b>.
                    <br><br>
                    <h3 class="title">Un défi personnel</h3>
                    C'est aussi un <b>challenge</b> lancé à moi-même, un moyen de <b>tester mes limites</b> face à l'inconnu et d'apprendre à être <b>autonome</b> dans un contexte différend chaque jour.
                    <br><br>
                    <i>Aussi, lorsque cette opportunité de voyager s'est de nouveau présentée à moi, je l'ai aussitôt saisie !</i>
                    <br><br>

                    <h2 class="title"  style="text-align: center;">La préparation</h2>
                    <h3 class="title">Le choix de la Nouvelle Zélande</h3>
                    Le choix du pays des Kiwis, comme les habitants se surnomment eux-mêmes, s'est fait petit-à-petit sur la base de différents <b>critères</b> :

                        <ul><li>un pays anglophone,</li>
                        <li>une île,</li>
                        <li>un climat tempéré,</li>
                        <li>une agricliture bien développée,</li>
                        <li>un pays éloigné de l'Europe, où j'ai déjà beaucoup voyagé</li></ul>

                    mais surtout :

                        <ul><li>la nature luxuriante,</li>
                        <li>les paysages extraordinaires,</li>
                        <li>l'accueil chaleureux des habitants,</li>
                        <li>la qualité de vie</li></ul>
                    <br>
                    <h3 class="title">La logistique</h3>
                    Après discussion avec mon employeur, nous sommes tombés d'accord sur un départ 6 mois plus tard, lui laissant le temps de pallier à mon départ.
                    <br><br>
                    Ma <b>préparation</b> s'est donc accéléré afin d'être prête en septembre, avec :

                        <ul><li>demande de visa,</li>
                        <li>obtention du permis de conduire (juste à temps !),</li>
                        <li>achat du billet d'avion,</li>
                        <li>inscriptions aux assurances santé et rapatriement,</li>
                        <li>vérification des vaccins et bilan médical,</li>
                        <li>résiliation des abonnements aux téléphone, internet gaz, électricité, ...</li>
                        <li>remplissage soigneux de la valise (23 kg pour 1 an de voyage c'est un challenge !),</li>
                        <li>dernière visite à la famille et aux amis.</li></ul>
                    <br>
                    <h3 class="title">Et c'est parti !</h3>
                    <div style="align: center;"><img src="./_include/img/nz/frtonz.png" alt="Fr to Nz" style="display: block;max-width: 80%;height: auto;"><br>
                    Le voyage m'a amené de Toulouse à Auckland, en passant par Paris et Shanghai en 50 longues heures.<br>
                    Après quelques jours pour me remettre de la fatigue et du jet-lag, la découverte de la Nouvelle-Zélande et d'Auckland peut commencer.<br>
                    <br>
                    Pour la découvrir aussi, cliquez sur ce lien : xxxx
                    <br><br>
                    <br><br>
                </div>
            </div>
        </div>
        <!-- End Title Page -->

      </div>
    </div>
  </div>
  <!-- End presentation Section -->


  <!-- Footer -->
  <?php include("footer.php"); ?>

  <!-- Js -->
  <script src="_include/js/jquery.min.js"></script> <!-- jQuery Core -->
  <script src="_include/js/bootstrap.min.js"></script> <!-- Bootstrap -->
  <script src="_include/js/supersized.3.2.7.min.js"></script> <!-- Slider -->
  <script src="_include/js/waypoints.js"></script> <!-- WayPoints -->
  <script src="_include/js/waypoints-sticky.js"></script> <!-- Waypoints for Header -->
  <script src="_include/js/jquery.isotope.js"></script> <!-- Isotope Filter -->
  <script src="_include/js/jquery.fancybox.pack.js"></script> <!-- Fancybox -->
  <script src="_include/js/jquery.fancybox-media.js"></script> <!-- Fancybox for Media -->
  <script src="_include/js/plugins.js"></script> <!-- Contains: jPreloader, jQuery Easing, jQuery ScrollTo, jQuery One Page Navi -->
  <script src="_include/js/main.js"></script> <!-- Defalit JS -->
  <script src="_include/js/i18next.js"></script> <!-- Translation -->
  <script src="_include/js/i18nextBrowserLanguageDetector.js"></script> <!-- Translation -->
  <script src="_include/js/trad_i18next_functions.js"></script>
  <script src="_include/js/trad_i18next_nz.js"></script> <!-- Translation -->
  <!-- End Js -->

</body>
</html>
