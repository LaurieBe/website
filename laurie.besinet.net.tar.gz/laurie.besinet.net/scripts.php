<!-- Js -->
<!-- script src="_include/js/jquery.min.js"></script> <!-- jQuery Core -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="_include/js/bootstrap.min.js"></script> <!-- Bootstrap -->
<script src="_include/js/supersized.3.2.7.min.js"></script> <!-- Slider -->
<script src="_include/js/waypoints.js"></script> <!-- WayPoints -->
<script src="_include/js/waypoints-sticky.js"></script> <!-- Waypoints for Header -->
<script src="_include/js/jquery.isotope.js"></script> <!-- Isotope Filter -->
<script src="_include/js/jquery.fancybox.pack.js"></script> <!-- Fancybox -->
<script src="_include/js/jquery.fancybox-media.js"></script> <!-- Fancybox for Media -->
<script src="_include/js/plugins.js"></script> <!-- Contains: jPreloader, jQuery Easing, jQuery ScrollTo, jQuery One Page Navi -->
<script src="_include/js/main.js"></script> <!-- Defalit JS -->
<script src="_include/js/i18next.js"></script> <!-- Translation -->
<script src="_include/js/i18nextBrowserLanguageDetector.js"></script> <!-- Translation -->
<script src="_include/js/trad_i18next_functions.js"></script>
<script src="_include/js/collapse.js"></script> <!-- collapse -->
<script src="_include/js/placeholder.js"></script>
<script src="_include/js/util.js"></script>
<script src="_include/js/scrollspy.js"></script> <!-- scrollspy -->

<!-- End Js -->
