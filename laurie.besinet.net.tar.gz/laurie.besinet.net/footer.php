<footer>
  <a href="#contact"> </a>
  <div id="social-area-title"> <h3 >Contact<h3></div>
  <div id="social-area">
    <div class="container">
      <nav id="social">
        <ul>
          <li><a href="mailto:laurie@besinet.net"><span class="font-icon-email_2"></span></li>
          <li><span style="font-weight:bold">laurie@besinet.net &nbsp&nbsp&nbsp&nbsp</span></li></a>
        </ul>
        <ul>
          <li><a title="Adress"><span class="font-icon-map-marker-2"></span></a></li>
          <li>From: Toulouse, FRANCE</li>
          <li>Current: <span style="font-weight:bold">Auckland, NEW ZEALAND &nbsp&nbsp&nbsp&nbsp</span></li>
        </ul>
        <ul>
          <li><a title="Phone"><span class="font-icon-phone"></span></a></li>
          <li>FR: +33 6 59 29 05 49</li>
          <li>NZ: <span style="font-weight:bold">+64 2 25 31 69 29 &nbsp&nbsp</span></li>
        </ul>
        <ul>
          <li><a href="https://twitter.com/lauriebesinet" title="Follow Me on Twitter" target="_blank"><span class="font-icon-social-twitter"></span></a></li>
          <li><a href="http://www.linkedin.com/in/lauriebesinet" title="Follow Me on LinkedIn" target="_blank"><span class="font-icon-social-linkedin"></span></a></li>
        </ul>

      </nav>
    </div>

    <div class="container">
      <nav>
        <ul><p class="credits">&copy;2017 Website by Laurie Besinet, based on a theme by <a href="http://www.alessioatzeni.com/" title="Alessio Atzeni | Web Designer &amp; Front-end Developer">Alessio Atzeni</a>. Pictures by Laurie Besinet unless mentionned.</p></ul>
      </nav>
    </div>

  </div>

</footer>

<!-- Back To Top -->
<a id="back-to-top" href="#content">
  <i class="font-icon-arrow-simple-up"></i>
</a>
