  <!-- Meta Tags -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

  <!-- Mobile Specifics -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="HandheldFriendly" content="true"/>
  <meta name="MobileOptimized" content="320"/>

  <!-- Bootstrap -->  <link href="_include/css/bootstrap.min.css" rel="stylesheet">

  <!-- Main Style -->  <link href="_include/css/main.css" rel="stylesheet" media="screen">

  <!-- Supersized -->  <link href="_include/css/supersized.css" rel="stylesheet" media="screen">
  <link href="_include/css/supersized.shutter.css" rel="stylesheet" media="screen">

  <!-- FancyBox -->  <link href="_include/css/fancybox/jquery.fancybox.css" rel="stylesheet" media="screen">

  <!-- Font Icons -->  <link href="_include/css/fonts.css" rel="stylesheet">

  <!-- Shortcodes -->  <link href="_include/css/shortcodes.css" rel="stylesheet" media="screen">

  <!-- Responsive -->
  <link href="_include/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
  <link href="_include/css/responsive.css" rel="stylesheet" media="screen">

  <!-- Supersized -->
  <link href="_include/css/supersized.css" rel="stylesheet" media="screen">
  <link href="_include/css/supersized.shutter.css" rel="stylesheet" media="screen">

  <!-- Print -->
  <link rel="stylesheet" type="text/css" href="_include/css/print.css" media="print">

  <!-- Google Font   <link href='_include/css/css?family=Titillium+Web.css' rel='stylesheet' type='text/css'>-->

  <!-- Fav Icon -->
  <link rel="shortcut icon" href="#">
  <link rel="apple-touch-icon" href="#">
  <link rel="apple-touch-icon" sizes="114x114" href="#">
  <link rel="apple-touch-icon" sizes="72x72" href="#">
  <link rel="apple-touch-icon" sizes="144x144" href="#">

  <!-- Modernizr -->  <script src="_include/js/modernizr.js"></script>

</head>
