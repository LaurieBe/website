<!-- Homepage Slider -->
<div id="home-slider">
    <div class="overlay"></div>

    <div class="slider-text">
      <div id="slidecaption"></div>
    </div>

  <div class="control-nav">



          <!--


          CHANGE HREF A CHAQUE PAGE v


        -->


          <a id="nextsection" href="#content"><i class="font-icon-arrow-simple-down"></i></a>
    </div>
  </div>

<!-- Header -->

<header>
    <div class="sticky-nav">
      <a id="mobile-nav" class="menu-nav" href="#menu-nav"></a>

        <div class="span1">
          <a id="goUp" href="index.php#home-slider" title="Laurie Besinet" style="line-height: 60px;"><img src="_include/img/LB logo nb fond transp.png" style="max-height: 40px;vertical-align: middle;"></a>
        </div>

        <nav id="menu">
          <ul id="menu-nav">
            <li><a class="external i18n_home" href="index.php#work"></a></li>
            <li><a class="external i18n_resume" href="cv.php#resume"></a></li>
            <li><a class="external i18n_blog" href="blog.php#blog"></a></li>
            <li><a class="i18n_contact" href="#social-area"></a></li>
            <li>
              <button class="button button-mini" onclick="i18next.changeLanguage('en')">EN</button>
              <button class="button button-mini" onclick="i18next.changeLanguage('fr')">FR</button>
            </li>
          </ul>
        </nav>

</header>
