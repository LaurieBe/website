<!-- Homepage Slider -->
<div id="home-slider">
    <div class="overlay"></div>

    <div class="slider-text">
      <div id="slidecaption"></div>
    </div>

    <div class="control-nav">
          <!-- <a id="prevslide" class="load-item"><i class="font-icon-arrow-simple-left"></i></a>
          <a id="nextslide" class="load-item"><i class="font-icon-arrow-simple-right"></i></a>
          <li id="slide-list"></li> -->

          <a id="nextsection" href="#nz"><i class="font-icon-arrow-simple-down"></i></a>
      </div>
</div>

<!-- Header -->

<header>
    <div class="sticky-nav">
      <a id="mobile-nav" class="menu-nav" href="#menu-nav"></a>

        <div class="span1">
          <a id="goUp" href="index.html" title="Laurie Besinet" style="line-height: 60px;"><img src="_include/img/LB logo nb fond transp.png" style="max-height: 40px;vertical-align: middle;"></a>
        </div>

        <!-- Menu -->

        <nav id="menu">
          <li id="menu-nav">
            <li><a href="index.html#work" class="external i18n_home"></a></li>
            <li><a class="external i18n_resume" href="cv.html#resume"></a></li>
            <li><a class="external i18n_newzealand" href="nz.php#nz"></a></li>
            <li><a class="i18n_contact" href="#social-area"></a></li>
            <li>
              <button class="button button-mini" onclick="i18next.changeLanguage('en')">EN</button>
              <button class="button button-mini" onclick="i18next.changeLanguage('fr')">FR</button>
            </li>
          </li>
        </nav>

      </div>
</header>
